# xkcd-pad
Control the [xkcd.com](xkcd.com) comic stream from your keyboard.

## Keyboard Shortcuts
* Left Arrow -> Go back one comic
* Right Arrow -> Go forward one comic
* ? (Question Mark) -> Go to a random comic
* < (Less-than Sign) -> Go to comic #1
* > (Greater-than Sign) -> Go to the most recent comic
* " "  (Space) -> Show or hide the current comic's alt-text

That's it. It doesn't do anything else.
